# Clínica Veterinaria MVC 🐾

Proyecto de la actividad práctica: **Clínica Veterinaria MVC** (CESDE / Comfama).
API REST construida con Spring Boot siguiendo el patrón MVC.

> "La Vista muestra, el Controlador decide y el Modelo guarda."

## Tecnologías
- Java 17
- Spring Boot 3.3.4
- Spring Data JPA + H2 (base de datos en memoria)
- Bean Validation (`spring-boot-starter-validation`)
- Maven

## Estructura del proyecto (MVC)
```
src/main/java/com/cesde/clinicaveterinaria/
 ├── model/         -> Mascota.java (el Modelo: datos y reglas de validación)
 ├── repository/    -> MascotaRepository.java (acceso a datos, vía JPA)
 ├── service/        -> MascotaService / MascotaServiceImpl (la lógica de negocio)
 ├── controller/     -> MascotaController.java (el Controlador: expone la API REST)
 └── exception/      -> Manejo centralizado de errores (404, 400, etc.)
```

## Cómo ejecutar el proyecto

### Requisitos
- Tener instalado **Java 17** o superior.
- Tener instalado **Maven** (o usar el wrapper `mvnw` si lo agregas).

### Pasos
1. Descomprime el proyecto y abre una terminal en la carpeta raíz (donde está `pom.xml`).
2. Ejecuta:
   ```bash
   mvn spring-boot:run
   ```
3. El servidor quedará disponible en: `http://localhost:8080`
4. La API queda expuesta en: `http://localhost:8080/api/mascotas`
5. (Opcional) Puedes ver la base de datos en el navegador en:
   `http://localhost:8080/h2-console`
   - JDBC URL: `jdbc:h2:mem:clinicadb`
   - Usuario: `sa` — Contraseña: (vacía)

Al arrancar, el proyecto ya carga 3 mascotas de prueba (ver `data.sql`), así que puedes
probar los `GET` inmediatamente.

## Endpoints disponibles

| Método | Ruta                          | Acción                              |
|--------|-------------------------------|--------------------------------------|
| GET    | `/api/mascotas`               | Listar todas las mascotas            |
| GET    | `/api/mascotas/{id}`          | Buscar una mascota por ID            |
| POST   | `/api/mascotas`               | Registrar una nueva mascota          |
| PUT    | `/api/mascotas/{id}`          | Actualizar una mascota existente     |
| DELETE | `/api/mascotas/{id}`          | Eliminar una mascota                 |
| GET    | `/api/mascotas/tipo/{tipo}`   | (Reto adicional) Buscar por tipo     |

### Ejemplo de body para POST / PUT
```json
{
  "nombre": "Firulais",
  "tipo": "Perro",
  "edad": 3,
  "duenio": "Carlos Perez"
}
```

### Respuestas de error
- **404** si el `id` no existe.
- **400** si los datos enviados no cumplen las validaciones (por ejemplo, `nombre` vacío).

## Colección de Postman
Se incluye el archivo `Clinica_Veterinaria_MVC.postman_collection.json` con las 7
pruebas obligatorias de la actividad (crear, listar, buscar, actualizar, eliminar,
error 404 y validación 400). Impórtalo directamente en Postman.
