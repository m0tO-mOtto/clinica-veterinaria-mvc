package com.cesde.clinicaveterinaria.service;

import com.cesde.clinicaveterinaria.model.Mascota;

import java.util.List;

public interface MascotaService {

    Mascota crear(Mascota mascota);

    List<Mascota> listarTodas();

    Mascota buscarPorId(Long id);

    Mascota actualizar(Long id, Mascota datosNuevos);

    void eliminar(Long id);

    List<Mascota> buscarPorTipo(String tipo);

}
