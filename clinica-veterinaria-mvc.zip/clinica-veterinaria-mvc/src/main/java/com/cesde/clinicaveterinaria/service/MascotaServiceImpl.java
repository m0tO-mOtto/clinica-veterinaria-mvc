package com.cesde.clinicaveterinaria.service;

import com.cesde.clinicaveterinaria.exception.MascotaNotFoundException;
import com.cesde.clinicaveterinaria.model.Mascota;
import com.cesde.clinicaveterinaria.repository.MascotaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MascotaServiceImpl implements MascotaService {

    private final MascotaRepository mascotaRepository;

    @Autowired
    public MascotaServiceImpl(MascotaRepository mascotaRepository) {
        this.mascotaRepository = mascotaRepository;
    }

    @Override
    public Mascota crear(Mascota mascota) {
        return mascotaRepository.save(mascota);
    }

    @Override
    public List<Mascota> listarTodas() {
        return mascotaRepository.findAll();
    }

    @Override
    public Mascota buscarPorId(Long id) {
        return mascotaRepository.findById(id)
                .orElseThrow(() -> new MascotaNotFoundException(id));
    }

    @Override
    public Mascota actualizar(Long id, Mascota datosNuevos) {
        Mascota existente = buscarPorId(id);

        existente.setNombre(datosNuevos.getNombre());
        existente.setTipo(datosNuevos.getTipo());
        existente.setEdad(datosNuevos.getEdad());
        existente.setDuenio(datosNuevos.getDuenio());

        return mascotaRepository.save(existente);
    }

    @Override
    public void eliminar(Long id) {
        Mascota existente = buscarPorId(id);
        mascotaRepository.delete(existente);
    }

    @Override
    public List<Mascota> buscarPorTipo(String tipo) {
        return mascotaRepository.findByTipoIgnoreCase(tipo);
    }
}
