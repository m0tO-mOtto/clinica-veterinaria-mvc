package com.cesde.clinicaveterinaria.repository;

import com.cesde.clinicaveterinaria.model.Mascota;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MascotaRepository extends JpaRepository<Mascota, Long> {

    List<Mascota> findByTipoIgnoreCase(String tipo);

}
