package com.cesde.clinicaveterinaria.exception;

import java.time.LocalDateTime;
import java.util.List;

public class ErrorResponse {

    private LocalDateTime fecha = LocalDateTime.now();
    private int estado;
    private String mensaje;
    private List<String> detalles;

    public ErrorResponse(int estado, String mensaje) {
        this.estado = estado;
        this.mensaje = mensaje;
    }

    public ErrorResponse(int estado, String mensaje, List<String> detalles) {
        this.estado = estado;
        this.mensaje = mensaje;
        this.detalles = detalles;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public int getEstado() {
        return estado;
    }

    public String getMensaje() {
        return mensaje;
    }

    public List<String> getDetalles() {
        return detalles;
    }
}
