package com.cesde.clinicaveterinaria.exception;

public class MascotaNotFoundException extends RuntimeException {

    public MascotaNotFoundException(Long id) {
        super("No se encontro ninguna mascota con el id " + id);
    }
}
