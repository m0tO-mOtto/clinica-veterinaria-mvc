INSERT INTO mascota (id, nombre, tipo, edad , duenio) VALUES ('1' ,'Firulais' , 'Perro','3', 'Carlos Perez');
INSERT INTO mascota (id, nombre, tipo, edad, duenio) VALUES ('2' , 'Michi', 'Gato', '2','Ana Gomez');
INSERT INTO mascota (id, nombre, tipo, edad, duenio) VALUES ('3' , 'Rocky', 'Perro', '5','Luisa Ramirez');
